<?php

return array(
    'rk_user' => 'rkuser',
    'rk_pass' => 'rkpass',
    "rk_host" => 'host',
    "rk_port" => 'port',
    'captcha_secret' => 'secret'
);
